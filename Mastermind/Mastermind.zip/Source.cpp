//This is my own work - Gaj Carson
#include "Guess.h"
#include "Game.h"

#include <iostream>

using namespace std;

int main()
{
	Game newGame;
	
	newGame.playGame();

	return 0;
}